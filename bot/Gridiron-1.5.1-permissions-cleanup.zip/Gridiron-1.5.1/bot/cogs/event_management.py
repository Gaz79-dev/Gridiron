import discord
from discord.ext import commands
from discord import app_commands, ui
import datetime
import traceback
import os
import pytz
from urllib.parse import urlencode
import asyncio
from typing import List, Dict, Optional
from collections import defaultdict
import uuid

# Use relative import to go up one level to the 'bot' package root
from ..utils.database import Database, RsvpStatus, ROLES, SUBCLASSES, RESTRICTED_ROLES

# --- Constants & Helpers ---
EMOJI_MAPPING = {
    "Commander": os.getenv("EMOJI_COMMANDER", "⭐"),
    "Infantry": os.getenv("EMOJI_INFANTRY", "💂"),
    "Armour": os.getenv("EMOJI_ARMOUR", "🛡️"),
    "Recon": os.getenv("EMOJI_RECON", "👁️"),
    "Pathfinders": os.getenv("EMOJI_PATHFINDERS", "🧭"),
    "Artillery": os.getenv("EMOJI_ARTILLERY", "💣"),
    "Anti-Tank": os.getenv("EMOJI_ANTI_TANK", "🚀"),
    "Assault": os.getenv("EMOJI_ASSAULT", "💥"),
    "Automatic Rifleman": os.getenv("EMOJI_AUTOMATIC_RIFLEMAN", "🔥"),
    "Engineer": os.getenv("EMOJI_ENGINEER", "🛠️"),
    "Machine Gunner": os.getenv("EMOJI_MACHINE_GUNNER", "💥"),
    "Medic": os.getenv("EMOJI_MEDIC", "➕"),
    "Officer": os.getenv("EMOJI_OFFICER", "🫡"),
    "Rifleman": os.getenv("EMOJI_RIFLEMAN", "👤"),
    "Support": os.getenv("EMOJI_SUPPORT", "🔧"),
    "Tank Commander": os.getenv("EMOJI_TANK_COMMANDER", "🧑‍✈️"),
    "Crewman": os.getenv("EMOJI_CREWMAN", "👨‍🔧"),
    "Spotter": os.getenv("EMOJI_SPOTTER", "👀"),
    "Sniper": os.getenv("EMOJI_SNIPER", "🎯"),
    "Unassigned": "❔"
}

CURATED_TIMEZONES = {
    "USA / Canada": [
        "US/Pacific", "US/Mountain", "US/Central", "US/Eastern",
        "Canada/Atlantic", "US/Alaska", "US/Hawaii"
    ],
    "UK / Europe": [
        "Europe/London", "Europe/Paris", "Europe/Berlin",
        "Europe/Helsinki", "Europe/Moscow"
    ],
    "Other": ["UTC"]
}

# --- FIX: Corrected Logic to check ALLOWED_ROLE_ID_1 through 5 ---
def has_required_role(member: discord.Member) -> bool:
    """Checks if a member has one of the roles specified in .env.

    Uses centralized logic shared with the global bot check.
    """
    return is_authorized_member(member)

    # If no roles are configured, default to allowing Server Administrators
    if not allowed_role_ids:
        return member.guild_permissions.administrator

    user_role_ids = {role.id for role in member.roles}
    
    # Check if user has an allowed role OR is an administrator
    return not user_role_ids.isdisjoint(allowed_role_ids) or member.guild_permissions.administrator

async def create_event_embed(bot: commands.Bot, event_id: int, db: Database) -> discord.Embed:
    event = await db.get_event_by_id(event_id)
    if not event:
        return discord.Embed(title="Error", description="Event not found.", color=discord.Color.red())

    guild = bot.get_guild(event['guild_id'])
    if not guild:
        return discord.Embed(title="Error", description="Could not find the server for this event.", color=discord.Color.red())

    signups = await db.get_signups_for_event(event_id)

    description = event.get('description', '')
    if restricted_ids := event.get('restrict_to_role_ids'):
        role_mentions = [f"<@&{role_id}>" for role_id in restricted_ids]
        if role_mentions:
            roles_text = ", ".join(role_mentions)
            restriction_notice = (
                f"**This is a restricted sign-up event.**\n"
                f"Only members of the following role(s) are permitted to sign-up: {roles_text}\n\n---\n\n"
            )
            description = restriction_notice + description

    embed = discord.Embed(title=f"📅 {event['title']}", description=description, color=discord.Color.blue())
    time_str = f"**Starts:** {discord.utils.format_dt(event['event_time'], style='F')} ({discord.utils.format_dt(event['event_time'], style='R')})"
    if event['end_time']:
        time_str += f"\n**Ends:** {discord.utils.format_dt(event['end_time'], style='F')}"
    if event['timezone']:
        time_str += f"\nTimezone: {event['timezone']}"
    embed.add_field(name="Time", value=time_str, inline=False)

    accepted_signups = defaultdict(list)
    tentative_users, declined_users = [], []

    for signup in signups:
        member = guild.get_member(signup['user_id'])
        if not member: continue

        status = signup['rsvp_status']
        if status == RsvpStatus.ACCEPTED:
            role_key = signup['role_name'] or "Unassigned"
            accepted_signups[role_key].append({
                "display_name": f"**{member.display_name}**",
                "subclass": signup['subclass_name']
            })
        elif status == RsvpStatus.TENTATIVE:
            tentative_users.append(member.display_name)
        elif status == RsvpStatus.DECLINED:
            declined_users.append(member.display_name)

    total_accepted = sum(len(v) for v in accepted_signups.values())
    embed.add_field(name=f"Accepted ({total_accepted})", value="\u200b", inline=False)

    def get_role_content_lines(role_name, signups):
        """Helper to build the text content for a single role category."""
        subclass_groups = defaultdict(list)
        for signup in signups:
            subclass_key = signup.get('subclass') or "Unassigned"
            subclass_groups[subclass_key].append(signup['display_name'])

        content_lines = [f"__**{role_name}**__ ({len(signups)})"]
        
        defined_subclasses = SUBCLASSES.get(role_name, [])
        
        if not defined_subclasses:
            if players := subclass_groups.get("Unassigned"):
                content_lines.extend(players)
                content_lines.append("") 
        else:
            subclass_order = defined_subclasses + ["Unassigned"]
            for subclass in subclass_order:
                if players := subclass_groups.get(subclass):
                    content_lines.append(f"__**{subclass}**__ ({len(players)})")
                    content_lines.extend(players)
                    content_lines.append("") 

        if content_lines and content_lines[-1] == "": content_lines.pop()
        return content_lines

    def chunk_content(lines: List[str], max_len: int = 1024) -> List[str]:
        if not lines: return []
        chunks = []
        current_chunk = ""
        for line in lines:
            if len(current_chunk) + len(line) + 1 > max_len:
                chunks.append(current_chunk)
                current_chunk = line
            else:
                current_chunk += f"\n{line}" if current_chunk else line
        chunks.append(current_chunk)
        return chunks

    col1_roles = ["Commander", "Infantry"]
    col2_roles = ["Armour", "Recon", "Pathfinders", "Artillery"]

    col1_lines = []
    for role_name in col1_roles:
        if signups := accepted_signups.get(role_name):
            if col1_lines: col1_lines.append("\n\n") 
            col1_lines.extend(get_role_content_lines(role_name, signups))

    col2_lines = []
    for role_name in col2_roles:
        if signups := accepted_signups.get(role_name):
            if col2_lines: col2_lines.append("\n\n")
            col2_lines.extend(get_role_content_lines(role_name, signups))

    col1_chunks = chunk_content(col1_lines)
    col2_chunks = chunk_content(col2_lines)

    num_rows = max(len(col1_chunks), len(col2_chunks))
    for i in range(num_rows):
        if i < len(col1_chunks):
            name = "Commander & Infantry"
            if len(col1_chunks) > 1: name += f" ({i+1}/{len(col1_chunks)})"
            embed.add_field(name=name, value=col1_chunks[i], inline=True)
        else:
            embed.add_field(name="\u200b", value="\u200b", inline=True)

        if i < len(col2_chunks):
            name = "Specialist Roles"
            if len(col2_chunks) > 1: name += f" ({i+1}/{len(col2_chunks)})"
            embed.add_field(name=name, value=col2_chunks[i], inline=True)
        else:
            embed.add_field(name="\u200b", value="\u200b", inline=True)
        
        if (i + 1) < num_rows:
            embed.add_field(name="\u200b", value="\u200b", inline=False)

    if num_rows > 0:
        embed.add_field(name="\u200b", value="\u200b", inline=False)

    if unassigned_signups := accepted_signups.get("Unassigned"):
        player_list = "\n".join(p['display_name'] for p in unassigned_signups)
        embed.add_field(name=f"__**Unassigned**__ ({len(unassigned_signups)})", value=player_list or "\u200b", inline=False)
    
    if tentative_users:
        embed.add_field(name=f"__**Tentative**__ ({len(tentative_users)})", value=", ".join(tentative_users), inline=False)
    
    if declined_users:
        embed.add_field(name=f"__**Declined**__ ({len(declined_users)})", value=", ".join(declined_users), inline=False)
    
    creator_name = "Unknown User"
    if creator_id := event.get('creator_id'):
        try:
            creator = guild.get_member(creator_id) or await guild.fetch_member(creator_id)
            creator_name = creator.display_name if creator else (await bot.fetch_user(creator_id)).name
        except discord.NotFound: pass

    embed.set_footer(text=f"Event ID: {event_id} | Created by: {creator_name}")
    return embed

# --- UI Classes ---

class RoleSelect(ui.Select):
    def __init__(self, db: Database, event_id: int, available_roles: List[str]):
        self.db, self.event_id = db, event_id
        options = [discord.SelectOption(label=r, emoji=EMOJI_MAPPING.get(r, "❔")) for r in available_roles]
        if not options:
            options.append(discord.SelectOption(label="No roles available for you", value="unassigned"))

        super().__init__(placeholder="1. Choose your primary role...", options=options)

    async def callback(self, i: discord.Interaction):
        selected_role = self.values[0]

        self.placeholder = f"Role: {selected_role}"
        self.disabled = True

        if selected_role == "unassigned":
            await self.db.update_signup_role(self.event_id, i.user.id, "Unassigned", None)
            await i.response.edit_message(content=f"Your role is set to **Unassigned** as no other roles were available.", view=self.view)
            asyncio.create_task(self.view.update_original_embed())
            self.view.stop()
            return

        self.view.role = selected_role
        subclass_select = self.view.subclass_select

        all_subclasses = SUBCLASSES.get(self.view.role, [])
        if not all_subclasses:
            await self.db.update_signup_role(self.event_id, i.user.id, self.view.role, None)
            await i.response.edit_message(content=f"Your role is confirmed as **{self.view.role}**!", view=self.view)
            self.view.stop()
            asyncio.create_task(self.view.update_original_embed())
            return

        event = await self.db.get_event_by_id(self.event_id)
        if not event:
            return await i.response.edit_message(content="Error: The event could not be found.", view=None)

        guild = self.view.bot.get_guild(event['guild_id'])
        if not guild:
            return await i.response.edit_message(content="Error: Bot is not in the event's server.", view=None)

        member = guild.get_member(i.user.id) or await guild.fetch_member(i.user.id)
        if not member:
            return await i.response.edit_message(content="Error: Could not find you in the event's server.", view=None)

        user_role_ids = {r.id for r in member.roles}

        restricted_roles_config = {
            "Officer": os.getenv("ROLE_ID_OFFICER"),
            "Tank Commander": os.getenv("ROLE_ID_TANK_COMMANDER"),
        }
        restricted_roles_config = {k: int(v) for k, v in restricted_roles_config.items() if v and v.isdigit()}

        available_subclasses = []
        for subclass in all_subclasses:
            if subclass not in RESTRICTED_ROLES:
                available_subclasses.append(subclass)
                continue

            required_role_id = restricted_roles_config.get(subclass)
            if not required_role_id or required_role_id in user_role_ids:
                available_subclasses.append(subclass)

        subclass_select.disabled = False
        subclass_select.placeholder = "2. Choose your subclass..."
        if available_subclasses:
            subclass_select.options = [discord.SelectOption(label=s, emoji=EMOJI_MAPPING.get(s, "❔")) for s in available_subclasses]
        else:
            subclass_select.options = [discord.SelectOption(label="No subclasses available", value="no_subclass_available")]
            subclass_select.placeholder = "No subclasses available for you"

        await i.response.edit_message(view=self.view)

class SubclassSelect(ui.Select):
    def __init__(self, db: Database, event_id: int):
        self.db, self.event_id = db, event_id
        super().__init__(placeholder="Select a primary role first...", disabled=True, options=[discord.SelectOption(label="placeholder")])

    async def callback(self, i: discord.Interaction):
        subclass = self.values[0]
        
        self.placeholder = f"Class: {subclass}"
        self.disabled = True

        await self.db.update_signup_role(self.event_id, i.user.id, self.view.role, subclass)
        await i.response.edit_message(content=f"Role confirmed: **{self.view.role} ({subclass})**!", view=self.view)
        self.view.stop()
        asyncio.create_task(self.view.update_original_embed())

class RoleSelectionView(ui.View):
    def __init__(self, bot: commands.Bot, db: Database, event_id: int, message_id: int, user: discord.User, available_roles: List[str]):
        super().__init__(timeout=300)
        self.bot, self.db, self.event_id, self.message_id, self.user, self.role = bot, db, event_id, message_id, user, None
        self.subclass_select = SubclassSelect(db, event_id)
        self.add_item(RoleSelect(db, event_id, available_roles))
        self.add_item(self.subclass_select)

    async def on_timeout(self):
        if self.role is None:
            await self.db.update_signup_role(self.event_id, self.user.id, "Unassigned", None)
            await self.update_original_embed()
            try: await self.user.send("Your role selection timed out. You are 'Unassigned'.")
            except discord.Forbidden: pass

    async def update_original_embed(self):
        if not (event := await self.db.get_event_by_id(self.event_id)): return
        try:
            channel = self.bot.get_channel(event['channel_id']) or await self.bot.fetch_channel(event['channel_id'])
            message = await channel.fetch_message(self.message_id)
            await message.edit(embed=await create_event_embed(self.bot, self.event_id, self.db))
        except (discord.NotFound, discord.Forbidden): pass

class NotificationTargetSelect(ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Accepted", value=RsvpStatus.ACCEPTED, emoji="✅", default=True),
            discord.SelectOption(label="Tentative", value=RsvpStatus.TENTATIVE, emoji="🤔"),
            discord.SelectOption(label="Declined", value=RsvpStatus.DECLINED, emoji="❌"),
        ]
        super().__init__(placeholder="Choose which groups to notify...", min_values=1, max_values=3, options=options)

    async def callback(self, interaction: discord.Interaction):
        self.view.selected_statuses = self.values
        await interaction.response.defer()

class NotificationSelectView(ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.value = None
        self.select_menu = NotificationTargetSelect()
        self.selected_statuses: List[str] = [RsvpStatus.ACCEPTED]
        self.add_item(self.select_menu)

    @ui.button(label="Send Notifications", style=discord.ButtonStyle.green, row=1)
    async def confirm(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        self.value = True
        self.stop()

    @ui.button(label="Skip Notifications", style=discord.ButtonStyle.red, row=1)
    async def cancel(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        self.value = False
        self.stop()

class PersistentEventView(ui.View):
    def __init__(self, db: Database):
        super().__init__(timeout=None)
        self.db = db

    async def update_embed(self, i: discord.Interaction, event_id: int):
        try: await i.message.edit(embed=await create_event_embed(i.client, event_id, self.db))
        except Exception as e: print(f"Error updating embed: {e}")

    @ui.button(label="Accept", style=discord.ButtonStyle.success, custom_id="persistent_view:accept")
    async def accept(self, i: discord.Interaction, button: ui.Button):
        await i.response.defer(ephemeral=True)
        event = await self.db.get_event_by_message_id(i.message.id)
        if not event: return await i.followup.send("Event not found.", ephemeral=True)

        restricted_roles_raw = event.get('restrict_to_role_ids')
        if restricted_roles_raw:
            allowed_role_ids = set()
            for rid in restricted_roles_raw:
                if rid is not None:
                    try:
                        allowed_role_ids.add(int(rid))
                    except (ValueError, TypeError):
                        pass

            user_role_ids = {r.id for r in i.user.roles}
            if allowed_role_ids and not user_role_ids.intersection(allowed_role_ids):
                role_mentions = [f'<@&{rid}>' for rid in allowed_role_ids]
                await i.followup.send(
                    f"Sorry, this event is restricted to members with the following role(s): {', '.join(role_mentions)}",
                    ephemeral=True
                )
                return 

        restricted_roles_config = {
            "Commander": os.getenv("ROLE_ID_COMMANDER"), "Officer": os.getenv("ROLE_ID_OFFICER"),
            "Recon": os.getenv("ROLE_ID_RECON"), "Tank Commander": os.getenv("ROLE_ID_TANK_COMMANDER"),
            "Pathfinders": os.getenv("ROLE_ID_PATHFINDER"), "Artillery": os.getenv("ROLE_ID_ARTY"),
        }
        restricted_roles_config = {k: int(v) for k, v in restricted_roles_config.items() if v and v.isdigit()}

        user_role_ids = {r.id for r in i.user.roles}
        available_roles = []

        for role in ROLES:
            if role not in RESTRICTED_ROLES:
                available_roles.append(role)
                continue

            required_role_id = restricted_roles_config.get(role)
            if not required_role_id or required_role_id in user_role_ids:
                available_roles.append(role)

        await self.db.set_rsvp(event['event_id'], i.user.id, RsvpStatus.ACCEPTED)

        try:
            if not available_roles:
                await self.db.update_signup_role(event['event_id'], i.user.id, "Unassigned", None)
                await i.followup.send("Accepted! There were no specific roles available for you, so you have been marked as 'Unassigned'.", ephemeral=True)
            else:
                view = RoleSelectionView(i.client, self.db, event['event_id'], i.message.id, i.user, available_roles)
                await i.user.send(f"You accepted **{event['title']}**. Select your role:", view=view)
                await i.followup.send("Check your DMs to select your role!", ephemeral=True)
        except discord.Forbidden:
            await self.db.update_signup_role(event['event_id'], i.user.id, "Unassigned", None)
            await i.followup.send("Accepted, but I couldn't DM you. Role set to 'Unassigned'.", ephemeral=True)

        await self.update_embed(i, event['event_id'])

    @ui.button(label="Tentative", style=discord.ButtonStyle.secondary, custom_id="persistent_view:tentative")
    async def tentative(self, i: discord.Interaction, button: ui.Button):
        await i.response.defer(ephemeral=True)
        try:
            if event := await self.db.get_event_by_message_id(i.message.id):
                restricted_roles_raw = event.get('restrict_to_role_ids')
                if restricted_roles_raw:
                    allowed_role_ids = set()
                    for rid in restricted_roles_raw:
                        if rid is not None:
                            try:
                                allowed_role_ids.add(int(rid))
                            except (ValueError, TypeError):
                                pass

                    user_role_ids = {r.id for r in i.user.roles}
                    if allowed_role_ids and not user_role_ids.intersection(allowed_role_ids):
                        role_mentions = [f'<@&{rid}>' for rid in allowed_role_ids]
                        await i.followup.send(
                            f"Sorry, this event is restricted to members with the following role(s): {', '.join(role_mentions)}",
                            ephemeral=True
                        )
                        return 

                await self.db.set_rsvp(event['event_id'], i.user.id, RsvpStatus.TENTATIVE)
                await self.db.update_signup_role(event['event_id'], i.user.id, None, None)
                await self.update_embed(i, event['event_id'])
                await i.followup.send("Your RSVP has been set to Tentative.", ephemeral=True)
        except Exception as e:
            print(f"Error in 'tentative' button: {e}")
            traceback.print_exc()
            try:
                await i.followup.send("An error occurred while processing your RSVP. Please try again.", ephemeral=True)
            except:
                pass

    @ui.button(label="Decline", style=discord.ButtonStyle.danger, custom_id="persistent_view:decline")
    async def decline(self, i: discord.Interaction, button: ui.Button):
        await i.response.defer(ephemeral=True)
        try:
            if event := await self.db.get_event_by_message_id(i.message.id):
                await self.db.set_rsvp(event['event_id'], i.user.id, RsvpStatus.DECLINED)
                await self.db.update_signup_role(event['event_id'], i.user.id, None, None)
                await self.update_embed(i, event['event_id'])
                await i.followup.send("Your RSVP has been set to Declined.", ephemeral=True)
        except Exception as e:
            print(f"Error in 'decline' button: {e}")
            traceback.print_exc()
            try:
                await i.followup.send("An error occurred while processing your RSVP. Please try again.", ephemeral=True)
            except:
                pass

    # --- RESTORED BUTTONS FOR EDIT/DELETE ---
    @ui.button(label="Edit", style=discord.ButtonStyle.primary, custom_id="persistent_view:edit_event", row=2)
    async def edit_event_button(self, interaction: discord.Interaction, button: ui.Button):
        if not has_required_role(interaction.user):
            return await interaction.response.send_message(
                "You do not have the required role to edit events.", ephemeral=True
            )

        event_cog = interaction.client.get_cog('EventManagement')
        if not event_cog:
            return await interaction.response.send_message(
                "An error occurred. The event management module may be offline.", ephemeral=True
            )

        event = await self.db.get_event_by_message_id(interaction.message.id)
        if not event:
            return await interaction.response.send_message(
                "This event could not be found in the database.", ephemeral=True
            )

        await interaction.response.send_message("I've sent you a DM to start the editing process.", ephemeral=True)
        await event_cog.start_conversation(interaction, mode='edit', event_id=event['event_id'])

    @ui.button(label="Delete", style=discord.ButtonStyle.danger, custom_id="persistent_view:delete_event", row=2)
    async def delete_event_button(self, interaction: discord.Interaction, button: ui.Button):
        if not has_required_role(interaction.user):
            return await interaction.response.send_message(
                "You do not have the required role to delete events.", ephemeral=True
            )

        event_cog = interaction.client.get_cog('EventManagement')
        if not event_cog:
            return await interaction.response.send_message(
                "An error occurred. The event management module may be offline.", ephemeral=True
            )

        event = await self.db.get_event_by_message_id(interaction.message.id)
        if not event:
            return await interaction.response.send_message(
                "This event could not be found in the database.", ephemeral=True
            )

        await interaction.response.send_message("I've sent you a DM to confirm the deletion.", ephemeral=True)
        await event_cog.start_delete_conversation(interaction, event['event_id'])

class ReminderConfirmationView(ui.View):
    def __init__(self):
        super().__init__(timeout=120)
        self.value = None

    @ui.button(label="Yes, Send Reminder", style=discord.ButtonStyle.green)
    async def confirm(self, i: discord.Interaction, button: ui.Button):
        await i.response.defer()
        self.value = True
        self.stop()

    @ui.button(label="No, Cancel", style=discord.ButtonStyle.red)
    async def reject(self, i: discord.Interaction, button: ui.Button):
        await i.response.defer()
        self.value = False
        self.stop()

class ConfirmationView(ui.View):
    def __init__(self):
        super().__init__(timeout=120)
        self.value = None

    @ui.button(label="Yes", style=discord.ButtonStyle.green)
    async def confirm(self, i: discord.Interaction, button: ui.Button):
        await i.response.defer()
        self.value = True
        self.stop()

    @ui.button(label="No/Skip", style=discord.ButtonStyle.red)
    async def reject(self, i: discord.Interaction, button: ui.Button):
        await i.response.defer()
        self.value = False
        self.stop()

class ReminderConversation:
    def __init__(self, cog: 'EventManagement', interaction: discord.Interaction, target_role: discord.Role, member_ids: list[int]):
        self.cog = cog
        self.bot = cog.bot
        self.db = cog.db
        self.user = interaction.user
        self.guild = interaction.guild
        self.target_role = target_role
        self.member_ids = member_ids
        self.is_finished = False

    async def _wait_for_message(self):
        return await self.bot.wait_for('message', check=lambda m: m.author == self.user and isinstance(m.channel, discord.DMChannel), timeout=300.0)

    async def start(self):
        try:
            if not await self.ask_for_confirmation():
                await self.user.send("Reminder cancelled.")
                return

            message_content = await self.ask_for_message()
            if not message_content:
                return

            await self.send_reminders(message_content)

        except asyncio.TimeoutError:
            await self.user.send("Your reminder request has timed out.")
        except Exception as e:
            print(f"Error in reminder conversation: {e}")
            traceback.print_exc()
            await self.user.send("An unexpected error occurred. The reminder has been cancelled.")
        finally:
            self.finish()

    async def ask_for_confirmation(self) -> bool:
        view = ReminderConfirmationView()
        msg = await self.user.send(
            f"You are about to send a reminder to **{len(self.member_ids)}** members of the '{self.target_role.name}' role. Do you wish to proceed?",
            view=view
        )
        await view.wait()
        if view.value is None:
            await msg.edit(content="Confirmation timed out.", view=None)
            return False

        await msg.delete()
        return view.value

    async def ask_for_message(self) -> Optional[str]:
        await self.user.send("Please type the reminder message you would like to send. Type `cancel` to stop.")
        try:
            message = await self._wait_for_message()
            if message.content.lower() == 'cancel':
                await self.user.send("Reminder cancelled.")
                return None
            return message.content
        except asyncio.TimeoutError:
            await self.user.send("Message input timed out. Reminder cancelled.")
            return None

    async def send_reminders(self, message_content: str):
        await self.user.send(f"Sending reminders to {len(self.member_ids)} members... This may take a moment.")

        success_count = 0
        fail_count = 0

        for member_id in self.member_ids:
            try:
                member = await self.guild.fetch_member(member_id)
                await member.send(message_content)
                success_count += 1
                await asyncio.sleep(0.5)
            except (discord.Forbidden, discord.HTTPException, discord.NotFound):
                fail_count += 1

        await self.user.send(
            f"Reminder process complete!\n"
            f"✅ Successfully sent to {success_count} member(s).\n"
            f"❌ Failed to send to {fail_count} member(s) (they may have DMs disabled or have left the server)."
        )

    def finish(self):
        self.is_finished = True
        if self.user.id in self.cog.active_conversations:
            del self.cog.active_conversations[self.user.id]

class Conversation:
    def __init__(self, cog: 'EventManagement', interaction: discord.Interaction, db: Database, event_id: int = None):
        self.cog, self.bot, self.interaction, self.user, self.db, self.event_id = cog, cog.bot, interaction, interaction.user, db, event_id
        self.data, self.is_finished = {}, False

    async def _wait_for_message(self):
        return await self.bot.wait_for(
            'message',
            check=lambda m: m.author == self.user and isinstance(m.channel, discord.DMChannel),
            timeout=300.0
        )

    async def start_creation(self):
        try:
            await self.user.send("Starting event creation. Type `cancel` at any time to stop.")
            steps = [
                ("What is the title of the event?", self.process_text, 'title'),
                (None, self.process_timezone, 'timezone'),
                ("What is the start date and time? Please use `DD-MM-YYYY HH:MM` format.", self.process_start_time, 'event_time'),
                ("What is the end date and time? Format: `DD-MM-YYYY HH:MM`.", self.process_end_time, 'end_time'),
                ("Please provide a detailed description for the event.", self.process_text, 'description'),
                (None, self.ask_mention_roles, 'mention_role_ids'),
                (None, self.ask_restrict_roles, 'restrict_to_role_ids'),
                (None, self.ask_is_recurring, 'is_recurring'),
            ]

            for prompt, processor, data_key in steps:
                if self.is_finished: break
                if not await processor(prompt, data_key):
                    await self.cancel()
                    return
            await self.finish()

        except Exception as e:
            print(f"Error during event creation conversation: {e}")
            traceback.print_exc()
            await self.cancel()

    async def start_editing(self):
        if not (event_data := await self.db.get_event_by_id(self.event_id)):
            await self.user.send("Could not find the event to edit.")
            return await self.cancel()

        self.data = dict(event_data)

        edit_options = {
            "1": ("Title", 'title', self.process_text),
            "2": ("Start Time", 'event_time', self.process_start_time),
            "3": ("End Time", 'end_time', self.process_end_time),
            "4": ("Description", 'description', self.process_text),
            "5": ("Mention Roles", 'mention_role_ids', self.ask_mention_roles),
            "6": ("Restrict Roles", 'restrict_to_role_ids', self.ask_restrict_roles),
        }

        is_child_event = self.data.get('parent_event_id') is not None
        if not is_child_event:
            edit_options["7"] = ("Timezone", 'timezone', self.process_timezone)
            edit_options["8"] = ("Is Recurring", 'is_recurring', self.ask_is_recurring)

        try:
            while not self.is_finished:
                summary_embed = self.create_summary_embed(edit_options)
                await self.user.send(
                    "Select a field to edit by replying with its number. Type `finish` to save or `cancel` to exit.",
                    embed=summary_embed
                )

                msg = await self._wait_for_message()
                choice = msg.content.lower()

                if choice == 'cancel':
                    await self.cancel()
                    break
                elif choice == 'finish':
                    await self.finish()
                    break
                elif choice in edit_options:
                    field_name, data_key, processor = edit_options[choice]
                    prompt = f"What is the new value for **{field_name}**?"
                    if not await processor(prompt, data_key):
                        await self.user.send(f"Editing for **{field_name}** was cancelled.")
                else:
                    await self.user.send("Invalid selection. Please try again.")

        except asyncio.TimeoutError:
            await self.user.send("Your editing session has timed out.")
            await self.cancel()
        except Exception as e:
            print(f"Error during event editing conversation: {e}")
            traceback.print_exc()
            await self.cancel()

    def create_summary_embed(self, edit_options: Dict) -> discord.Embed:
        embed = discord.Embed(title="Event Editor", description="Current event details:", color=discord.Color.orange())
        guild = self.interaction.guild

        for num, (name, key, _) in edit_options.items():
            value = self.data.get(key)
            display_value = "Not set"

            if value is not None:
                if key in ['event_time', 'end_time'] and isinstance(value, datetime.datetime):
                    try:
                        target_tz_str = self.data.get('timezone', 'UTC')
                        target_tz = pytz.timezone(target_tz_str)
                    except pytz.UnknownTimeZoneError:
                        target_tz = pytz.utc

                    local_time = value.astimezone(target_tz)
                    display_value = local_time.strftime('%d-%m-%Y %H:%M')
                elif key in ['mention_role_ids', 'restrict_to_role_ids']:
                    role_names = [r.name for r_id in value if (r := guild.get_role(r_id))]
                    display_value = ", ".join(role_names) if role_names else "None"
                elif key == 'is_recurring':
                    display_value = "Yes" if value else "No"
                    if value and (rule := self.data.get('recurrence_rule')):
                        display_value += f" ({rule.capitalize()})"
                elif key not in ['is_recurring']:
                    display_value = str(value)

            embed.add_field(name=f"`{num}`. {name}", value=f"```{display_value or 'Not Set'}```", inline=False)

        return embed

    async def process_text(self, prompt, data_key):
        await self.user.send(prompt)
        try:
            msg = await self._wait_for_message()
            if msg.content.lower() == 'cancel': return False
            self.data[data_key] = msg.content
            return True
        except asyncio.TimeoutError:
            await self.user.send("Conversation timed out.")
            return False

    async def process_timezone(self, prompt, data_key):
        flat_tz_list = [tz for region in CURATED_TIMEZONES.values() for tz in region]

        description_lines = []
        count = 1
        for region, timezones in CURATED_TIMEZONES.items():
            description_lines.append(f"\n**__{region}__**")
            for tz in timezones:
                description_lines.append(f"`{count}` {tz}")
                count += 1

        embed = discord.Embed(title="Please Select a Timezone", description="\n".join(description_lines), color=discord.Color.blue())
        await self.user.send("Please reply with the number for your desired timezone.", embed=embed)

        try:
            msg = await self._wait_for_message()
            if msg.content.lower() == 'cancel': return False

            choice = int(msg.content)
            if 1 <= choice <= len(flat_tz_list):
                self.data[data_key] = flat_tz_list[choice - 1]
                await self.user.send(f"Timezone set to **{self.data[data_key]}**.")
                return True
            else:
                await self.user.send("Invalid number. Please try again.")
                return await self.process_timezone(prompt, data_key)
        except (ValueError, asyncio.TimeoutError):
            await self.user.send("Invalid input or conversation timed out.")
            return False

    async def process_start_time(self, prompt, data_key):
        p = prompt + "\nPlease use `DD-MM-YYYY HH:MM` format."
        await self.user.send(p)
        try:
            msg = await self._wait_for_message()
            if msg.content.lower() == 'cancel': return False
            try:
                naive_dt = datetime.datetime.strptime(msg.content, "%d-%m-%Y %H:%M")
                selected_tz_str = self.data.get('timezone', 'UTC')
                selected_tz = pytz.timezone(selected_tz_str)
                self.data[data_key] = selected_tz.localize(naive_dt)
                return True
            except ValueError:
                await self.user.send("Invalid date format. Let's try again.")
                return await self.process_start_time(prompt, data_key)
        except asyncio.TimeoutError:
            await self.user.send("Conversation timed out.")
            return False

    async def process_end_time(self, prompt, data_key):
        p = prompt + "\nPlease use `DD-MM-YYYY HH:MM` format."
        await self.user.send(p)
        try:
            msg = await self._wait_for_message()
            if msg.content.lower() == 'cancel': return False
            try:
                naive_dt = datetime.datetime.strptime(msg.content, "%d-%m-%Y %H:%M")
                selected_tz_str = self.data.get('timezone', 'UTC')
                selected_tz = pytz.timezone(selected_tz_str)
                self.data[data_key] = selected_tz.localize(naive_dt)
                return True
            except ValueError:
                await self.user.send("Invalid date format. Let's try again.")
                return await self.process_end_time(prompt, data_key)
        except asyncio.TimeoutError:
            await self.user.send("Conversation timed out.")
            return False

    async def ask_is_recurring(self, prompt, data_key):
        view = ConfirmationView()
        msg = await self.user.send("Is this a recurring event?", view=view)
        await view.wait()
        await msg.edit(content=msg.content, view=None)
        if view.value is None:
            await self.user.send("Timed out.")
            return False

        self.data['is_recurring'] = view.value
        if view.value:
            return await self.process_recurrence_rule(None, 'recurrence_rule')

        self.data['recurrence_rule'], self.data['recreation_hours'] = None, None
        return True

    async def process_recurrence_rule(self, prompt, data_key):
        p = "How often should it recur? (`daily`, `weekly`, `monthly`)"
        await self.user.send(p)
        try:
            msg = await self._wait_for_message()
            if msg.content.lower() == 'cancel': return False
            rule = msg.content.lower()
            if rule not in ['daily', 'weekly', 'monthly']:
                await self.user.send("Invalid input.")
                return await self.process_recurrence_rule(prompt, data_key)
            self.data[data_key] = rule
            return await self.process_recreation_hours(None, 'recreation_hours')
        except asyncio.TimeoutError:
            await self.user.send("Conversation timed out.")
            return False

    async def process_recreation_hours(self, prompt, data_key):
        p = "How many hours before the event should the new embed be created? (e.g., `168` for 7 days)"
        await self.user.send(p)
        try:
            msg = await self._wait_for_message()
            if msg.content.lower() == 'cancel': return False
            try:
                self.data[data_key] = int(msg.content)
                return True
            except ValueError:
                await self.user.send("Please enter a valid number.")
                return await self.process_recreation_hours(prompt, data_key)
        except asyncio.TimeoutError:
            await self.user.send("Conversation timed out.")
            return False

    async def _ask_roles(self, prompt, data_key, question):
        view = ConfirmationView()
        msg = await self.user.send(question, view=view)
        await view.wait()
        await msg.edit(content=msg.content, view=None)

        if view.value is None: return False

        if view.value:
            guild_roles = sorted([r for r in self.interaction.guild.roles if r.name != "@everyone" and not r.managed], key=lambda r: r.position, reverse=True)

            description_lines = [f"`{i+1}` {role.name}" for i, role in enumerate(guild_roles)]

            embed = discord.Embed(title="Please Select Role(s)", description="\n".join(description_lines), color=discord.Color.blue())
            await self.user.send("Please reply with the number(s) for your desired roles, separated by commas (e.g., `1, 5, 12`).", embed=embed)

            try:
                msg = await self._wait_for_message()
                if msg.content.lower() == 'cancel': return False

                selected_indices = [int(i.strip()) - 1 for i in msg.content.split(',')]
                selected_role_ids = [guild_roles[i].id for i in selected_indices if 0 <= i < len(guild_roles)]

                self.data[data_key] = selected_role_ids
                if not selected_role_ids:
                     await self.user.send("No valid roles selected.")
                else:
                    names = [guild_roles[i].name for i in selected_indices if 0 <= i < len(guild_roles)]
                    await self.user.send(f"Roles set to: **{', '.join(names)}**")
                return True
            except (ValueError, asyncio.TimeoutError, IndexError):
                await self.user.send("Invalid input or conversation timed out.")
                return False
        else:
            self.data[data_key] = []
            return True

    async def ask_mention_roles(self, p, dk): return await self._ask_roles(p, dk, "Mention roles in the announcement?")
    async def ask_restrict_roles(self, p, dk): return await self._ask_roles(p, dk, "Restrict sign-ups to specific roles?")

    async def finish(self):
        if self.is_finished: return
        self.is_finished = True
        del self.cog.active_conversations[self.user.id]

        try:
            if self.event_id:
                await self.db.update_event(self.event_id, self.data)

                update_embed = await create_event_embed(self.bot, self.event_id, self.db)

                notify_view = ConfirmationView()
                msg = await self.user.send("Would you like to notify attendees of the changes?", view=notify_view)
                await notify_view.wait()
                await msg.delete()

                user_ids_to_notify = []
                if notify_view.value:
                    select_view = NotificationSelectView()
                    select_msg = await self.user.send("Please select the RSVP groups to notify, then click Send.", view=select_view)
                    await select_view.wait()

                    if select_view.value is True:
                        # --- FIX: Read from the view's state, not the component's values ---
                        statuses_to_notify = select_view.selected_statuses
                        if statuses_to_notify:
                            signups = await self.db.get_signups_for_event(self.event_id)
                            user_ids_to_notify = [s['user_id'] for s in signups if s['rsvp_status'] in statuses_to_notify]
                        else:
                            await self.user.send("No RSVP groups were selected. Skipping notifications.")
                    else:
                        await self.user.send("Notification step skipped.")

                    await select_msg.delete()
                else:
                    await self.user.send("Okay, no notifications will be sent.")

                try:
                    event_for_message = self.data
                    if self.data.get('is_recurring') and not self.data.get('parent_event_id'):
                        latest_child = await self.db.get_latest_child_event(self.event_id)
                        event_for_message = latest_child if latest_child else self.data

                    if 'channel_id' in event_for_message and event_for_message.get('message_id'):
                        channel = self.bot.get_channel(event_for_message['channel_id']) or await self.bot.fetch_channel(event_for_message['channel_id'])
                        message = await channel.fetch_message(event_for_message['message_id'])
                        embed = await create_event_embed(self.bot, self.event_id, self.db)
                        view = PersistentEventView(self.db)
                        content = " ".join([f"<@&{rid}>" for rid in self.data.get('mention_role_ids', [])])
                        await message.edit(content=content, embed=embed, view=view)
                        await self.user.send("✅ Event embed successfully updated in the channel.")
                    else:
                        await self.user.send("✅ Event data updated, but no message was found to edit.")

                except (discord.NotFound, discord.Forbidden, KeyError) as e:
                    print(f"Error updating main embed: {e}")
                    await self.user.send("⚠️ Event data was updated, but I couldn't find or edit the original event message.")

                if self.data.get('thread_id'):
                    try:
                        thread = await self.bot.fetch_channel(self.data['thread_id'])
                        event_time = self.data['event_time']
                        date_str = event_time.strftime('%b %d')
                        new_thread_name = f"{self.data['title']} - {date_str}"
                        await thread.edit(name=new_thread_name)
                        await thread.send(content="@everyone Please note, the event details have been updated.", embed=update_embed, allowed_mentions=discord.AllowedMentions(everyone=True))
                        await self.user.send("✅ Renamed the event thread and posted an update.")
                    except Exception as e:
                        await self.user.send(f"⚠️ Could not update the thread: {e}")

                if user_ids_to_notify:
                    await self.user.send(f"Now sending a DM to {len(user_ids_to_notify)} selected attendee(s)...")
                    success_count = 0
                    for user_id in user_ids_to_notify:
                        try:
                            member = self.interaction.guild.get_member(user_id) or await self.interaction.guild.fetch_member(user_id)
                            await member.send(f"Please note that the event **{self.data['title']}** has been updated.", embed=update_embed)
                            success_count += 1
                        except (discord.Forbidden, discord.NotFound):
                            continue
                    await self.user.send(f"✅ Successfully notified {success_count}/{len(user_ids_to_notify)} attendees.")

            else:
                if self.data.get('is_recurring'):
                    parent_id = await self.db.create_event(self.interaction.guild.id, self.interaction.channel.id, self.user.id, self.data)
                    await self.user.send(f"✅ Recurring parent template created (ID: {parent_id}). You can manage this from the Events page on the website.")
                    await self.user.send(f"⏳ The first event occurrence will be created and posted by the scheduler based on your `recreation_hours` setting.")
                else:
                    event_id = await self.db.create_event(self.interaction.guild.id, self.interaction.channel.id, self.user.id, self.data)
                    embed = await create_event_embed(self.bot, event_id, self.db)
                    view = PersistentEventView(self.db)
                    content = " ".join([f"<@&{rid}>" for rid in self.data.get('mention_role_ids', [])])
                    target_channel = self.bot.get_channel(self.interaction.channel.id)

                    if target_channel:
                        msg = await target_channel.send(content=content, embed=embed, view=view)
                        await self.db.update_event_message_id(event_id, msg.id)
                        await self.user.send(f"✅ Event created successfully! (ID: {event_id}).")
                    else:
                        await self.user.send("⚠️ Event created, but I could not find the channel to post it in.")

        except Exception as e:
            print(f"Error finishing conversation: {e}")
            traceback.print_exc()
            await self.user.send("An unexpected error occurred while saving the event.")

    async def cancel(self):
        if self.is_finished: return
        self.is_finished = True
        if self.user.id in self.cog.active_conversations: del self.cog.active_conversations[self.user.id]
        await self.user.send("Event creation/editing cancelled")

class DeleteConfirmationView(ui.View):
    def __init__(self):
        super().__init__(timeout=120)
        self.value = None

    @ui.button(label="Yes, Delete Event", style=discord.ButtonStyle.danger)
    async def confirm_delete(self, interaction: discord.Interaction, button: ui.Button):
        self.value = True
        for item in self.children: item.disabled = True
        await interaction.response.edit_message(content="Confirmed. Proceeding...", view=self)
        self.stop()

    @ui.button(label="No, Cancel", style=discord.ButtonStyle.secondary)
    async def cancel_delete(self, interaction: discord.Interaction, button: ui.Button):
        self.value = False
        for item in self.children: item.disabled = True
        await interaction.response.edit_message(content="Deletion cancelled.", view=self)
        self.stop()

class EventManagement(commands.Cog):
    def __init__(self, bot: commands.Bot, db: Database):
        self.bot = bot
        self.db = db
        self.active_conversations = {}

    event_group = app_commands.Group(name="event", description="Commands for creating and managing events.")

    async def role_autocomplete(self, interaction: discord.Interaction, current: str) -> List[app_commands.Choice[str]]:
        roles = interaction.guild.roles
        return [
            app_commands.Choice(name=role.name, value=str(role.id))
            for role in roles if current.lower() in role.name.lower() and not role.is_default()
        ][:25]

    @event_group.command(name="create", description="Create a new event via DM.")
    async def create(self, interaction: discord.Interaction):
        # --- FIX: ADDED SECURITY CHECK ---
        if not has_required_role(interaction.user):
            return await interaction.response.send_message(
                "⛔ You do not have permission to create events.",
                ephemeral=True
            )

        if interaction.guild is None:
            await interaction.response.send_message(
                "This command cannot be used in a Direct Message. Please run it in the desired event channel.",
                ephemeral=True
            )
            return
        await self.start_conversation(interaction, mode='create')

    @event_group.command(name="edit", description="Edit an existing event via DM.")
    @app_commands.describe(event_id="The ID of the event to edit.")
    async def edit(self, interaction: discord.Interaction, event_id: int):
        if not (event := await self.db.get_event_by_id(event_id)):
            return await interaction.response.send_message("Event not found.", ephemeral=True)
        await self.start_conversation(interaction, mode='edit', event_id=event_id)

    @event_group.command(name="delete", description="Deletes an event via a DM conversation.")
    @app_commands.describe(event_id="The ID of the event to delete.")
    async def delete(self, interaction: discord.Interaction, event_id: int):
        if not interaction.user.guild_permissions.administrator:
            if interaction.response.is_done():
                await interaction.followup.send("You must be an administrator to delete events.", ephemeral=True)
            else:
                await interaction.response.send_message("You must be an administrator to delete events.", ephemeral=True)
            return

        event = await self.db.get_event_by_id(event_id)
        if not event or event['guild_id'] != interaction.guild_id:
            if interaction.response.is_done():
                await interaction.followup.send("Event not found or it does not belong to this server.", ephemeral=True)
            else:
                await interaction.response.send_message("Event not found or it does not belong to this server.", ephemeral=True)
            return

        if event.get('deleted_at'):
            if interaction.response.is_done():
                await interaction.followup.send("This event has already been deleted.", ephemeral=True)
            else:
                await interaction.response.send_message("This event has already been deleted.", ephemeral=True)
            return

        if not interaction.response.is_done():
            await interaction.response.send_message("I've sent you a DM to confirm the deletion.", ephemeral=True)

        await self.start_delete_conversation(interaction, event_id)

    @event_group.command(name="restore", description="Restores a previously deleted event.")
    @app_commands.describe(event_id="The ID of the event to restore.")
    async def restore(self, interaction: discord.Interaction, event_id: int):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("You must be an administrator to restore events.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        event = await self.db.get_event_by_id(event_id, include_deleted=True)
        if not event or event['guild_id'] != interaction.guild_id:
            return await interaction.followup.send("Event not found.", ephemeral=True)

        if not event.get('deleted_at'):
            return await interaction.followup.send("This event is already active.", ephemeral=True)

        await self.db.restore_event(event_id)

        try:
            channel = self.bot.get_channel(event['channel_id']) or await self.bot.fetch_channel(event['channel_id'])
            embed = await create_event_embed(self.bot, event_id, self.db)
            view = PersistentEventView(self.db)
            content = " ".join([f"<@&{rid}>" for rid in event.get('mention_role_ids', [])])

            new_message = await channel.send(content=content, embed=embed, view=view)
            await self.db.update_event_message_id(event_id, new_message.id)
            await interaction.followup.send(f"Event '{event['title']}' has been restored and re-posted.")
        except Exception as e:
            await interaction.followup.send(f"Event data was restored, but failed to re-post the embed: {e}")

    @event_group.command(name="remind", description="Send a DM reminder to members of a role who have not RSVP'd.")
    @app_commands.describe(
        event_id="The ID of the event to send reminders for.",
        role="The role to target for reminders."
    )
    @app_commands.autocomplete(role=role_autocomplete)
    @app_commands.default_permissions(administrator=True)
    async def remind(self, interaction: discord.Interaction, event_id: int, role: str):
        await interaction.response.send_message("Preparing your reminder, please check your DMs...", ephemeral=True)

        if interaction.user.id in self.active_conversations:
            return await interaction.followup.send("You are already in an active conversation with me. Please finish or cancel it first.", ephemeral=True)

        try:
            role_id = int(role)
            target_role = interaction.guild.get_role(role_id)
            if not target_role:
                return await interaction.followup.send("The selected role could not be found.", ephemeral=True)
        except ValueError:
            return await interaction.followup.send("Invalid role selected.", ephemeral=True)

        event = await self.db.get_event_by_id(event_id)
        if not event or event['guild_id'] != interaction.guild_id:
            return await interaction.followup.send("Event not found in this server.", ephemeral=True)

        rsvpd_user_ids = await self.db.get_all_rsvpd_user_ids_for_event(event_id)

        member_ids_to_remind = []
        for member in target_role.members:
            if not member.bot and member.id not in rsvpd_user_ids:
                member_ids_to_remind.append(member.id)

        if not member_ids_to_remind:
            return await interaction.followup.send(
                f"No members of the '{target_role.name}' role need a reminder for this event. They have all RSVP'd.",
                ephemeral=True
            )

        conv = ReminderConversation(self, interaction, target_role, member_ids_to_remind)
        self.active_conversations[interaction.user.id] = conv
        asyncio.create_task(conv.start())

    async def start_conversation(self, interaction: discord.Interaction, mode: str, event_id: int = None):
        """Starts a conversation in DMs for either creating or editing an event."""
        if interaction.user.id in self.active_conversations:
            if interaction.response.is_done():
                await interaction.followup.send("You are already in an active conversation with me. Please finish or cancel it first.", ephemeral=True)
            else:
                await interaction.response.send_message("You are already in an active conversation with me. Please finish or cancel it first.", ephemeral=True)
            return

        if not interaction.response.is_done():
            await interaction.response.send_message("I've sent you a DM to start the process!", ephemeral=True)

        try:
            conv = Conversation(self, interaction, self.db, event_id)
            self.active_conversations[interaction.user.id] = conv

            if mode == 'create':
                asyncio.create_task(conv.start_creation())
            elif mode == 'edit':
                asyncio.create_task(conv.start_editing())

        except discord.Forbidden:
            if interaction.response.is_done():
                await interaction.followup.send("I couldn't send you a DM. Please check your privacy settings.", ephemeral=True)

    async def start_delete_conversation(self, interaction: discord.Interaction, event_id: int):
        """Starts the dedicated conversation for deleting an event."""
        if interaction.user.id in self.active_conversations:
            if interaction.response.is_done():
                await interaction.followup.send("You are already in an active conversation with me. Please finish or cancel it first.", ephemeral=True)
            else:
                await interaction.response.send_message("You are already in an active conversation with me. Please finish or cancel it first.", ephemeral=True)
            return

        try:
            conv = DeleteConversation(self, interaction, self.db, event_id)
            self.active_conversations[interaction.user.id] = conv
            asyncio.create_task(conv.start())

        except discord.Forbidden:
             if interaction.response.is_done():
                await interaction.followup.send("I couldn't send you a DM. Please check your privacy settings.", ephemeral=True)

class DeleteConversation:
    def __init__(self, cog: 'EventManagement', interaction: discord.Interaction, db: Database, event_id: int):
        self.cog = cog
        self.bot = cog.bot
        self.user = interaction.user
        self.guild = interaction.guild
        self.db = db
        self.event_id = event_id
        self.is_finished = False

    async def start(self):
        """Guides the user through deleting an event."""
        try:
            event = await self.db.get_event_by_id(self.event_id)
            if not event:
                await self.user.send("This event could not be found in the database. It may have already been deleted.")
                return self.finish()

            confirm_view = DeleteConfirmationView()
            msg = await self.user.send(f"Are you sure you want to delete the event **{event['title']}**? This action cannot be undone via the bot.", view=confirm_view)
            await confirm_view.wait()

            if confirm_view.value is not True:
                await msg.edit(content="Deletion cancelled.", view=None)
                return self.finish()

            await msg.edit(content="Deletion confirmed. Preparing to delete assets...", view=None)

            notify_view = ConfirmationView()
            notify_msg = await self.user.send("Would you like to notify accepted attendees via DM that the event has been cancelled?", view=notify_view)
            await notify_view.wait()
            should_notify = notify_view.value
            await notify_msg.edit(content="Okay, proceeding with deletion...", view=None)

            if event.get('message_id'):
                try:
                    channel = self.bot.get_channel(event['channel_id']) or await self.bot.fetch_channel(event['channel_id'])
                    message = await channel.fetch_message(event['message_id'])
                    await message.delete()
                    await self.user.send("✅ Event message in channel deleted.")
                except Exception as e:
                    await self.user.send(f"⚠️ Could not delete the event message in the channel: {e}")

            if event.get('thread_id'):
                try:
                    thread = self.bot.get_channel(event['thread_id']) or await self.bot.fetch_channel(event['thread_id'])
                    await thread.delete()
                    await self.user.send("✅ Event discussion thread deleted.")
                except Exception as e:
                    await self.user.send(f"⚠️ Could not delete the event thread: {e}")

            if should_notify:
                signups = await self.db.get_signups_for_event(self.event_id)
                accepted_ids = [s['user_id'] for s in signups if s['rsvp_status'] == RsvpStatus.ACCEPTED]

                if accepted_ids:
                    await self.user.send(f"Now sending cancellation notices to {len(accepted_ids)} attendees...")
                    success_count = 0
                    for user_id in accepted_ids:
                        try:
                            member = self.guild.get_member(user_id) or await self.guild.fetch_member(user_id)
                            await member.send(f"Please be advised that the event **{event['title']}** has been cancelled.")
                            success_count += 1
                        except (discord.Forbidden, discord.NotFound):
                            continue
                    await self.user.send(f"✅ Successfully notified {success_count}/{len(accepted_ids)} attendees.")
                else:
                    await self.user.send("No accepted attendees to notify.")

            await self.db.soft_delete_event(self.event_id)
            await self.user.send("✅ Event has been marked as deleted in the database.")

        except asyncio.TimeoutError:
            await self.user.send("Your session has timed out. Deletion cancelled.")
        except Exception as e:
            print(f"Error during event deletion conversation: {e}")
            traceback.print_exc()
            await self.user.send("An unexpected error occurred. Please check the bot's logs.")
        finally:
            self.finish()

    def finish(self):
        """Cleans up the active conversation."""
        self.is_finished = True
        if self.user.id in self.cog.active_conversations:
            del self.cog.active_conversations[self.user.id]

async def setup(bot: commands.Bot):
    """Sets up the event management cog."""
    cog = EventManagement(bot, bot.db)
    await bot.add_cog(cog)
    bot.add_view(PersistentEventView(bot.db))
