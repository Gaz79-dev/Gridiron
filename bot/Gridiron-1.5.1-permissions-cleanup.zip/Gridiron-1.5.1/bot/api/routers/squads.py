from fastapi import APIRouter, Depends
from typing import Dict, Optional

from bot.api import auth
from bot.api.dependencies import get_db
from bot.utils.database import Database, ROLES, SUBCLASSES
from bot.api.models import RoleUpdateRequest, SquadMoveRequest, StartupTaskUpdateRequest, SquadReorderRequest
from bot.cogs.event_management import EMOJI_MAPPING

router = APIRouter(prefix="/api/squads", tags=["squads"], dependencies=[Depends(auth.get_current_active_user)])

@router.get("/roles", response_model=Dict)
async def get_all_roles(db: Database = Depends(get_db)):
    return await db.get_all_roles_and_subclasses()

@router.get("/emojis", response_model=Dict[str, str])
async def get_emojis():
    return EMOJI_MAPPING

@router.put("/members/{squad_member_id}/role", status_code=204)
async def update_member_role(squad_member_id: int, request: RoleUpdateRequest, db: Database = Depends(get_db)):
    await db.update_squad_member_role(squad_member_id, request.new_role_name)
    member_details = await db.get_squad_member_details(squad_member_id)
    if not member_details: return

    user_id, new_primary_role, new_subclass_name = member_details['user_id'], None, None
    for role, subclasses in SUBCLASSES.items():
        if request.new_role_name in subclasses:
            new_primary_role, new_subclass_name = role, request.new_role_name
            break
    if not new_primary_role and request.new_role_name in ROLES:
        new_primary_role = request.new_role_name
    
    if new_primary_role:
        await db.update_signup_role(request.event_id, user_id, new_primary_role, new_subclass_name)

    # --- FIX: Flag the event for an embed update after a role change ---
    await db.flag_event_for_embed_update(request.event_id)

@router.put("/members/{squad_member_id}/move", status_code=204)
async def move_member_to_squad(squad_member_id: int, request: SquadMoveRequest, db: Database = Depends(get_db)):
    await db.move_squad_member(squad_member_id, request.new_squad_id)

@router.put("/{squad_id}/reorder", status_code=204)
async def reorder_squad_members(
    squad_id: int,
    request: SquadReorderRequest,
    db: Database = Depends(get_db)
):
    """
    Updates the manual sort order of members within a squad.
    """
    await db.update_squad_member_order(squad_id, request.ordered_member_ids)

@router.put("/members/{squad_member_id}/task", status_code=204)
async def update_member_startup_task(
    squad_member_id: int,
    request: StartupTaskUpdateRequest,
    db: Database = Depends(get_db)
):
    """Assigns a startup task to a squad member."""
    # If the task is an empty string, store it as NULL in the database
    task_to_store = request.task if request.task else None
    await db.update_squad_member_task(squad_member_id, task_to_store)
