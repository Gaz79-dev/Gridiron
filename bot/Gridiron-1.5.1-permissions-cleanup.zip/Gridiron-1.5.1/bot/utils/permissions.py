import os
from functools import lru_cache
from typing import Optional, Set

import discord


@lru_cache(maxsize=1)
def get_allowed_role_ids() -> Set[int]:
    """Load allowed role IDs from env once and cache them."""
    ids: Set[int] = set()
    for i in range(1, 6):
        v = os.getenv(f"ALLOWED_ROLE_ID_{i}")
        if not v:
            continue
        try:
            ids.add(int(v))
        except ValueError:
            # Ignore malformed values rather than breaking bot startup
            continue
    return ids


def is_authorized_member(member: Optional[discord.Member]) -> bool:
    """Return True if the member has at least one allowed role.

    If no allowed roles are configured, returns True (opt-in restriction).
    """
    allowed = get_allowed_role_ids()
    if not allowed:
        return True
    if member is None:
        return False
    return any(getattr(r, "id", None) in allowed for r in getattr(member, "roles", []))


def is_authorized_interaction(interaction: discord.Interaction) -> bool:
    """Convenience wrapper for interactions."""
    member: Optional[discord.Member]
    if isinstance(interaction.user, discord.Member):
        member = interaction.user
    elif interaction.guild:
        member = interaction.guild.get_member(interaction.user.id)
    else:
        member = None
    return is_authorized_member(member)
